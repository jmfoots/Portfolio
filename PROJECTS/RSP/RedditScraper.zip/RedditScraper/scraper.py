#Imports
from browsermobproxy import Server
from selenium import webdriver
from selenium.webdriver.common.proxy import *
from datetime import datetime as dt
from PIL import Image
import json,re,os,time,random,urllib.request,io, psutil,hashlib,sys
#Vars
new = []
used = []
images = './BG'
sources=[html for html in open('./subreddits.csv', "r")]
writing=False
first=True
prev=""
#Functions
def clear():
    try:
        for log in ['./bmp.log','./geckodriver.log','./server.log']:
            try:
                os.unlink(log)
            except:
                pass
        for img in os.listdir(images):
            try:
                os.unlink(os.path.join(images, img))
            except Exception as e:
                continue
    except:
        pass
def display(src):
    global writing; global prev; global first
    naxt = download(src)
    if os.path.exists(naxt):
        sleep=0
        while writing or sleep<5:
            if first and not writing:
                first=False
                break
            sleep+=1
            time.sleep(1)
            if not writing and sleep>=5:
                time.sleep(1)
                break
        os.startfile(naxt)
        if os.path.exists(prev) and len(os.listdir(images))>1:
            os.unlink(prev)
        prev = naxt
def download(src):
    global writing
    out = os.path.abspath(images+'/'+src.split("/")[-1].split('?')[0])
    if not os.path.exists(out):
        writing=True
        try:
            img = Image.open(io.BytesIO(urllib.request.urlopen(src, timeout=10).read()))
            img.save(out)
        except:
            pass
        writing=False
    return out
#Reset
clear()
#Main
try:
    server = Server("C:\\Utility\\browsermob-proxy-2.1.4\\bin\\browsermob-proxy.bat")
    server.start()
    proxy = server.create_proxy()
    os.environ['MOZ_HEADLESS'] = '1'
    profile = webdriver.FirefoxProfile()
    profile.set_preference("dom.webnotifications.enabled", False)
    profile.set_preference("http.response.timeout", 5)
    profile.set_preference("dom.max_script_run_time", 10)
    profile.set_proxy(proxy.selenium_proxy())
    driver = webdriver.Firefox(firefox_profile=profile)
    while len(sources) >= 1:
        source = random.choice(sources)
        print("Selected: "+source)
        sources.remove(source)
        proxy.new_har(source)
        driver.get(source)
        try:
            xpath = "/html/body/div[1]/div/div/div/div[2]/div/div/div[1]/div/div/div[2]/a[2]"
            driver.find_element_by_xpath(xpath).click()
        except:
            pass
        entry = 0
        while entry < len(proxy.har['log']['entries'])-1:
            entry+=1
            driver.execute_script("window.scrollByPages(1)")
            request = proxy.har['log']['entries'][entry]['request']
            url = request['url']
            md5 = hashlib.md5(url.encode('utf-8')).hexdigest()
            if 'redd.it' in url and url not in new and md5 not in used:
                if driver.find_elements_by_xpath("//*[contains(@href,'alb.reddit')]//descendant::img[@src='"+url+"']"):
                    continue
                new.append(url)
        print("Found: "+str(len(new))+" Images")
        while len(new) >= 1:
            url = random.choice(new)
            used.append(md5)
            new.remove(url)
            display(url)
    raise Exception
except (Exception, KeyboardInterrupt, SystemExit) as e:
    print(e)
    print("Stopping")
    try:
        proxy.close()
    except:
        pass
    try:
        driver.quit()
    except:
        pass
    for proc in psutil.process_iter():
        try:
            if proc.name() in ['Honeyview.exe', 'java.exe','firefox.exe']:
                proc.kill()
        except psutil.NoSuchProcess:
            pass
    clear()
    print("Done")
